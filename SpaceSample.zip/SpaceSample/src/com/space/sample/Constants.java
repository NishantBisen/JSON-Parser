package com.space.sample;

public class Constants {

	public static final String URL = "http://mydeatree.appspot.com/api/v1/public_ideas/";
	
	public static final String TAG_OBJECTS = "objects";
	
	public static final String TAG_TITLE = "title";
	public static final String TAG_DATECREATED = "created_date";
	public static final String TAG_TEXT = "text";
	
	
}
